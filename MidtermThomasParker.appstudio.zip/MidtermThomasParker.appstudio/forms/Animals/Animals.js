/*
let myAnimals = ['dog','cat','horse','meerkat']

let newAnimal = prompt('Please enter a new animal')

myAnimals.push(newAnimal)

console.log(myAnimals)

alert(`The last animal is a ${myAnimals[myAnimals.length-1]}`)
*/