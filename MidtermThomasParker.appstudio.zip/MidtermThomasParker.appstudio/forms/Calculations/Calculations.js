/*
function calcAvgSquare(n1,n2,n3){

  let n1Sqr = Math.pow(n1,2)

  let avgSqr = ((n1+n2+n3)/3)*n1Sqr

  return avgSqr

  }

let numb1 = Number(prompt('Enter a number'))
let numb2 =  Number(prompt('Enter a number'))
let numb3 =  Number(prompt('Enter a number'))

let myAnswer = calcAvgSquare(numb1,numb2,numb3)

alert(`The answer is ${myAnswer}`)
*/