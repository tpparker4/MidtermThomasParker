/*
myAnimals = ['dog','cat','horse','meerkat']

newAnimal = prompt('Please enter a new animal')

myAnimals.push(newAnimal)

console.log(myAnimals)

newAnimalTwo = prompt('Please enter a second animal')

myAnimals.push(newAnimalTwo)

console.log(myAnimals)

alert(`The last two animals are ${myAnimals[myAnimals.length-1]} and ${myAnimals[myAnimals.length-2]}`)
*/
